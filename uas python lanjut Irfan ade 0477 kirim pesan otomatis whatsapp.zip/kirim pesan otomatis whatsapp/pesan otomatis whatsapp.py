import pywhatkit
import pyautogui
import time

pywhatkit.sendwhatmsg("+628xxxxxxxxxx:","Halo ",22,25)
time.sleep(1)
pyautogui.click()
time.sleep(1)
pyautogui.press('enter')